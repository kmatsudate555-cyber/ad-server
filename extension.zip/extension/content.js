// Meta広告ライブラリのDOM構造に対応したContent Script

const SAVE_BTN_CLASS = "ad-saver-btn";
const SAVED_BTN_CLASS = "ad-saver-btn--saved";

// 認証状態をキャッシュ
let isLoggedIn = false;

// 起動時に認証状態を確認
chrome.runtime.sendMessage({ type: "GET_AUTH_STATE" }, (res) => {
  isLoggedIn = res?.isLoggedIn || false;
});

// DOMの変化を監視して広告カードを検出
const observer = new MutationObserver(() => {
  injectSaveButtons();
});

observer.observe(document.body, { childList: true, subtree: true });

// 初回実行
setTimeout(injectSaveButtons, 2000);

function injectSaveButtons() {
  // Meta広告ライブラリの広告カードを特定するセレクタ
  // （実際のDOMに合わせて調整が必要な場合あり）
  const adCards = document.querySelectorAll(
    '[data-testid="ad-archive-preview"], ._7jyr, [class*="x1lliihq"][class*="x6ikm8r"]'
  );

  // セレクタが合わない場合のフォールバック：広告を含む可能性のある大きなカード
  const fallbackCards = document.querySelectorAll('[class*="xh8yej3"]');
  const cards = adCards.length > 0 ? adCards : fallbackCards;

  cards.forEach((card) => {
    if (card.querySelector(`.${SAVE_BTN_CLASS}`)) return; // 既にボタンあり

    const adData = extractAdData(card);
    if (!adData.advertiser_name && !adData.image_url && !adData.ad_text) return;

    const btn = createSaveButton(adData);
    card.style.position = "relative";
    card.appendChild(btn);
  });
}

function extractAdData(card) {
  const data = {
    page_url: window.location.href,
    ad_id: null,
    advertiser_name: null,
    ad_text: null,
    start_date: null,
    image_url: null,
    video_url: null,
    tags: [],
  };

  // 広告ID（URLパラメータまたはdata属性から）
  const urlParams = new URLSearchParams(window.location.search);
  const idFromUrl = urlParams.get("id");
  if (idFromUrl) data.ad_id = idFromUrl;

  // 広告主名
  const nameEl =
    card.querySelector('a[href*="/pages/"] strong') ||
    card.querySelector('[class*="x193iq5w"]') ||
    card.querySelector("h4") ||
    card.querySelector('a[role="link"] span');
  if (nameEl) data.advertiser_name = nameEl.innerText.trim();

  // 広告テキスト
  const textEl =
    card.querySelector('[data-testid="ad-archive-preview-body"]') ||
    card.querySelector('[class*="xdj266r"]') ||
    card.querySelector("p");
  if (textEl) data.ad_text = textEl.innerText.trim().slice(0, 1000);

  // 開始日
  const dateEl = card.querySelector('[class*="x1cy8zhl"] span');
  if (dateEl && dateEl.innerText.includes("~")) {
    data.start_date = dateEl.innerText.trim();
  }

  // 画像URL
  const imgEl = card.querySelector("img[src*='fbcdn'], img[src*='scontent']");
  if (imgEl) data.image_url = imgEl.src;

  // 動画URL
  const videoEl = card.querySelector("video source, video[src]");
  if (videoEl) {
    data.video_url = videoEl.src || videoEl.getAttribute("src");
  }

  return data;
}

function createSaveButton(adData) {
  const btn = document.createElement("button");
  btn.className = SAVE_BTN_CLASS;
  btn.innerHTML = `<span class="ad-saver-icon">&#128190;</span> 保存`;
  btn.title = "Ad Saverに保存";

  btn.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (!isLoggedIn) {
      showToast("ログインしてください（拡張機能アイコンをクリック）", "error");
      return;
    }

    btn.disabled = true;
    btn.innerHTML = `<span class="ad-saver-icon">&#9203;</span> 保存中...`;

    chrome.runtime.sendMessage({ type: "SAVE_AD", payload: adData }, (res) => {
      if (res?.success) {
        btn.className = `${SAVE_BTN_CLASS} ${SAVED_BTN_CLASS}`;
        btn.innerHTML = `<span class="ad-saver-icon">&#10003;</span> 保存済み`;
        btn.disabled = true;
        showToast("広告を保存しました！", "success");
      } else {
        btn.disabled = false;
        btn.innerHTML = `<span class="ad-saver-icon">&#128190;</span> 保存`;
        showToast(res?.error || "保存に失敗しました", "error");
      }
    });
  });

  return btn;
}

function showToast(message, type = "success") {
  const existing = document.getElementById("ad-saver-toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.id = "ad-saver-toast";
  toast.className = `ad-saver-toast ad-saver-toast--${type}`;
  toast.textContent = message;

  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// background.jsからの認証状態更新を受け取る
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "AUTH_STATE_CHANGED") {
    isLoggedIn = message.isLoggedIn;
  }
});
